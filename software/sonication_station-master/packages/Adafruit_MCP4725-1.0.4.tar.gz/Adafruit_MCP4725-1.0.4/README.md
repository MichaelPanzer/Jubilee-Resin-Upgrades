DEPRECATED LIBRARY Adafruit Python MCP4725
===================

This library has been deprecated!

we are now only using our circuitpython sensor libraries in python

we are leaving the code up for historical/research purposes but archiving the repository.

check out this guide for using the mcp4725 with python!
https://learn.adafruit.com/mcp4725-12-bit-dac-tutorial/python-circuitpython

# 
Python code to use the MCP4725 digital to analog converter with a Raspberry Pi or BeagleBone black.

## Installation

To install the library from source (recommended) run the following commands on a Raspberry Pi or other Debian-based OS system:

    sudo apt-get install git build-essential python-dev
    cd ~
    git clone https://github.com/adafruit/Adafruit_Python_MCP4725.git
    cd Adafruit_Python_MCP4725
    sudo python setup.py install

Alternatively you can install from pip with:

    sudo pip install adafruit-mcp4725

Note that the pip install method **won't** install the example code.
