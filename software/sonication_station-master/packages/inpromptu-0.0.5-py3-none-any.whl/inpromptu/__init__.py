from .inpromptu import cli_method
from .inpromptu import UserInputError
from .inpromptu import Inpromptu

